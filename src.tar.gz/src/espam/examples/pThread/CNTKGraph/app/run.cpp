//============================================================================
// Name        : erqian_proj2.cpp
// Author      : Minakova S.
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include "appMain.h"

using namespace std;



int main() {
	//cout << "!!!Hello World!!!" << endl; // prints !!!Hello World!!!
	appMain app = appMain();
	app.main();

	return 0;
}
