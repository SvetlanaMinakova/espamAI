package espam.datamodel.graph.cnn.neurons.normalization;

import espam.datamodel.graph.cnn.neurons.simple.NonLinear;

public class BN extends NonLinear {
}
