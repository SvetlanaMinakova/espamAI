package espam.datamodel.graph.cnn.neurons;

/** interface shows, that Neuron contains Data inside*/
public interface DataContainer {
}
