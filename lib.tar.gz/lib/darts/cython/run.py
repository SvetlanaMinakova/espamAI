#!/usr/bin/python

import itertools

from phrt_dse import phrt_dse

phrt_dse(source_file="chain1", MAX_SCALING=20, MAX_FOLDING_FACTOR=7)
