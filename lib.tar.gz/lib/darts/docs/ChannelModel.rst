ChannelModel Module
===================

.. automodule:: ChannelModel
    :members:
    :undoc-members:
    :show-inheritance:
