TextHandler Module
==================

.. automodule:: TextHandler
    :members:
    :undoc-members:
    :show-inheritance:
