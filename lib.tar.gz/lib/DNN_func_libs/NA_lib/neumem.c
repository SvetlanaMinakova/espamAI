#include "neumem.h"

heap_desc_t neul2heap;
heap_desc_t neuDDRheap;
