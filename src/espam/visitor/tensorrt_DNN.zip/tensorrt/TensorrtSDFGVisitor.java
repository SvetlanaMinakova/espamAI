package espam.visitor.tensorrt;

import espam.datamodel.graph.cnn.Layer;
import espam.datamodel.graph.cnn.Network;
import espam.datamodel.graph.csdf.CSDFGraph;
import espam.utils.fileworker.FileWorker;
import espam.visitor.tensorrt.cpp.CPPSDFGVisitorTensorrt;
import espam.visitor.tensorrt.h.HSDFGVisitorTensorrt;

import java.util.Iterator;

public class TensorrtSDFGVisitor {
    /**
     * Call SDFG Visitor
     * @param y  CSDFGraph
     * @param dir directory for sesame templates
     * @param dnn corresponding deep neural network
     */
     public static void callVisitor(Network dnn, CSDFGraph y, String dir) {
         //_setDummySchedule(dnn,y);
         //setLoadWeightsFolder(dir.replace("/pthread/","/weights/"));
         //setLoadWeights();
         //_setDataTypes(dnn.getDataType(),dnn.getWeightsType());

         callVisitor(dnn,dir);
     }

    /**
     * Call CPP SDFG Visitor
     * @param y  CSDFGraph
     * @param dir directory for sesame templates
     */
     public static void callVisitor(Network y, String dir){
     String templatesDir = dir + "app/";
     try {
         /** if templates directory already exists,
          *  remove it and all templates inside it*/
         FileWorker.recursiveDelete(templatesDir);
         _cppVisitor.generateMainClassTemplate(dir, y);
         _cppVisitor.callDNNVisitor(y, dir);
         _hvisitor.callDNNVisitor(y, dir);

         /** generate classes (.cpp and .h files) for each SDF graph node */




           /**
          * Generate classes, used by all the node-classes of
          * the application
          */
         //_generateAppStandardFuncs(templatesDir,y);


         System.out.println("espamAI-Tensorrt application generated in: " + templatesDir);
     }

        catch (Exception e){
         System.err.println(templatesDir + "espamAI-Tensorrt application generation error: " + e.getMessage());

        }
     }

     ///////////////////////////////////////////////////////////////////
    ////                     private variables                     ///

    /** header-files visitor*/
    public static HSDFGVisitorTensorrt _hvisitor = new HSDFGVisitorTensorrt();

    /**C++ code-files visitor*/
    public static CPPSDFGVisitorTensorrt _cppVisitor = new CPPSDFGVisitorTensorrt();

}
